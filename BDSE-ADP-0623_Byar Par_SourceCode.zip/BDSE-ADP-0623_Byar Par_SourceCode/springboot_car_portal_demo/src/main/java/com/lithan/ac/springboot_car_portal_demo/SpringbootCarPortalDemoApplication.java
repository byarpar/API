package com.lithan.ac.springboot_car_portal_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCarPortalDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCarPortalDemoApplication.class, args);
	}

}
